<?php

use App\Http\Controllers\DashboardController;
use Illuminate\Support\Facades\Route;

/*
| These are page shells only. Authentication is enforced client-side by
| resources/js/app.js, which redeems the HttpOnly refresh cookie on load and
| redirects to /login when there is no usable session. The data behind the
| pages is served by the JWT-guarded /api/v1 endpoints, so a shell reaching an
| unauthenticated visitor exposes nothing.
*/

Route::view('/login', 'auth.login')->name('login');

/*
| Sign-up. Gated server-side rather than merely hidden: with self-serve
| onboarding turned off, the page must not exist at all, or it would offer a
| form whose endpoint answers 403.
*/
Route::get('/register', function () {
    abort_unless((bool) config('tenancy.allow_public_signup', true), 404);

    return view('auth.register');
})->name('register');

Route::get('/dashboard', DashboardController::class)->name('dashboard');

// Accounting shells.
Route::view('/accounts', 'accounts.index')->name('accounts.index');
Route::view('/parties', 'parties.index')->name('parties.index');
Route::view('/items', 'items.index')->name('items.index');
Route::view('/stock', 'stock.index')->name('stock.index');
Route::view('/bills', 'bills.index')->name('bills.index');
Route::view('/journal', 'journal.index')->name('journal.index');
Route::view('/ledger', 'ledger.index')->name('ledger.index');
Route::view('/reports', 'reports.index')->name('reports.index');

// Go-live. Used once per workshop, which is why it sits under Settings in the
// nav rather than competing with the screens somebody opens every day.
Route::view('/opening', 'opening.index')->name('opening.index');

// The caller's own workshop: identity and the settings every report is built on.
Route::view('/workspace', 'workspace.index')->name('workspace.index');

// Stored files — M14. An upload returns as soon as the bytes are away; whether
// they can be read back is watched rather than waited on.
Route::view('/uploads', 'uploads.index')->name('uploads.index');

// The trail — M13. Who changed what, when: the master data underneath the
// figures, which is the part the ledger's own immutability does not cover.
Route::view('/audit', 'audit.index')->name('audit.index');

// Administration shells. The tables inside are filled from the guarded API, and
// every control is additionally gated on the user's grants client-side.
Route::view('/tenants', 'tenants.index')->name('tenants.index');
Route::view('/users', 'users.index')->name('users.index');
Route::view('/roles', 'roles.index')->name('roles.index');

Route::redirect('/', '/dashboard');
