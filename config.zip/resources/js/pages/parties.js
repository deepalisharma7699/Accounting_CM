import auth from '../auth-client';
import { can } from '../permissions';
import {
    $, $$, clearFormErrors, confirmAction, debounce, esc, formatDate, formatMoney,
    hideModal, isZeroAmount, setSubmitting, showFormErrors, showModal, tableMessage, toast,
} from '../ui';

/**
 * Customers and suppliers.
 *
 * The list carries each party's outstanding position, which is the number
 * anybody opening this page actually came for. It is derived from the ledger on
 * every read — there is no stored balance to go stale — and fetched for the
 * whole page in one request rather than one per row, via `with_position=1`.
 *
 * Receivable and payable are shown in separate columns and never netted. For
 * the counterparty who is both, "they owe you ₹40,000 and you owe them ₹38,000"
 * is two facts that get settled separately; collapsing them into "₹2,000" is
 * true and useless.
 */

const PAGE_SIZE = 25;
const LEDGER_PAGE_SIZE = 50;

const state = {
    search: '',
    role: '',
    isActive: '1',
    page: 1,
    lastPage: 1,
    ledger: { partyId: null, page: 1, lastPage: 1 },
};

/* -------------------------------------------------------------------------
 | The list
 | ---------------------------------------------------------------------- */

async function loadParties() {
    const body = $('#parties-body');
    body.innerHTML = tableMessage(6, 'Loading parties…');

    const params = new URLSearchParams({
        per_page: PAGE_SIZE,
        page: state.page,
        // The outstanding column. Opt-in, because it costs a query over the
        // ledger and a picker has no use for it.
        with_position: '1',
    });

    if (state.search) params.set('search', state.search);
    if (state.role) params.set('role', state.role);
    if (state.isActive !== '') params.set('is_active', state.isActive);

    try {
        const payload = await auth.call(`/parties?${params}`);

        render(payload.data, payload.meta?.pagination);
    } catch (error) {
        // A platform super-admin holds every permission but belongs to no
        // workshop, so they can reach this page by typing the URL and there is
        // nothing to show them. Not their mistake — say so plainly.
        body.innerHTML = error.code === 'NO_WORKSPACE'
            ? tableMessage(6, 'Your account administers the platform rather than a single workshop, so it has no parties of its own.')
            : tableMessage(6, error.message, 'error');

        $('#parties-summary').textContent = '';
        $('#new-party')?.classList.add('hidden');
        setPager(1, 1);
    }
}

function render(parties, pagination) {
    const body = $('#parties-body');

    if (!parties.length) {
        body.innerHTML = tableMessage(6, state.search
            ? 'No parties match that search.'
            : 'No parties yet. Add the first customer or supplier to get started.');

        $('#parties-summary').textContent = '';
        setPager(1, 1);

        return;
    }

    body.innerHTML = parties.map(renderRow).join('');

    const total = pagination?.total ?? parties.length;
    $('#parties-summary').textContent = `${total} part${total === 1 ? 'y' : 'ies'}.`;

    state.lastPage = pagination?.last_page ?? 1;
    setPager(pagination?.current_page ?? 1, state.lastPage);
}

function renderRow(party) {
    const mayUpdate = can('UPDATE', 'PARTIES');
    const mayDelete = can('DELETE', 'PARTIES');
    const mayReadLedger = can('READ', 'LEDGER');

    const outstanding = party.outstanding ?? null;

    return `
        <tr class="border-t border-border transition hover:bg-secondary/60 ${party.is_active ? '' : 'opacity-60'}">
            <td class="table-cell">
                <div class="flex items-center gap-2">
                    <span class="font-semibold">${esc(party.name)}</span>
                    ${party.is_active ? '' : '<span class="badge bg-muted text-muted-foreground">Archived</span>'}
                </div>
                ${party.phone || party.email
                    ? `<div class="mt-0.5 truncate text-[0.8125rem] text-muted-foreground">${esc([party.phone, party.email].filter(Boolean).join(' · '))}</div>`
                    : ''}
            </td>

            <td class="table-cell w-40">
                <div class="flex flex-wrap gap-1">
                    ${(party.role_labels ?? []).map((label) =>
                        `<span class="badge bg-accent text-accent-foreground">${esc(label)}</span>`).join('')}
                </div>
            </td>

            <td class="table-cell w-44 font-mono text-[0.8125rem] text-muted-foreground">
                ${party.gstin ? esc(party.gstin) : '—'}
            </td>

            ${amountCell(outstanding?.receivable)}
            ${amountCell(outstanding?.payable)}

            <td class="table-cell w-32">
                <div class="flex justify-end gap-1">
                    ${mayReadLedger ? `<button type="button" class="btn btn-ghost btn-icon" data-ledger="${party.id}"
                            data-name="${esc(party.name)}" title="Statement" aria-label="Statement for ${esc(party.name)}">${iconStatement}</button>` : ''}
                    ${mayUpdate ? `<button type="button" class="btn btn-ghost btn-icon" data-edit="${party.id}"
                            title="Edit party" aria-label="Edit ${esc(party.name)}">${iconPencil}</button>` : ''}
                    ${mayUpdate ? archiveButton(party) : ''}
                    ${mayDelete ? `<button type="button" class="btn btn-ghost btn-icon" data-delete="${party.id}"
                            data-name="${esc(party.name)}" title="Delete party" aria-label="Delete ${esc(party.name)}">${iconTrash}</button>` : ''}
                </div>
            </td>
        </tr>`;
}

/**
 * A dash for nothing owed, and an em dash for "nobody asked" — the API sends
 * null when the position was not fetched, and a zero when it genuinely is zero.
 * Showing both as "0.00" would tell a reader an account is settled when nobody
 * looked.
 */
function amountCell(amount) {
    if (amount === undefined || amount === null) {
        return '<td class="table-cell w-36 text-right font-mono text-[0.8125rem] text-muted-foreground">—</td>';
    }

    return isZeroAmount(amount)
        ? '<td class="table-cell w-36 text-right font-mono text-[0.8125rem] text-muted-foreground">—</td>'
        : `<td class="table-cell w-36 text-right font-mono text-[0.8125rem] font-semibold">${esc(formatMoney(amount))}</td>`;
}

function archiveButton(party) {
    const label = party.is_active ? 'Archive party' : 'Restore party';

    return `<button type="button" class="btn btn-ghost btn-icon" data-toggle="${party.id}"
                    data-name="${esc(party.name)}" data-active="${party.is_active ? '1' : '0'}"
                    title="${label}" aria-label="${label}">${party.is_active ? iconArchive : iconRestore}</button>`;
}

function setPager(current, last) {
    $('#page-prev').disabled = current <= 1;
    $('#page-next').disabled = current >= last;
}

const iconPencil = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M21.17 6.83a2.83 2.83 0 0 0-4-4L3.5 16.5 2 22l5.5-1.5z"/><path d="m15 5 4 4"/></svg>';
const iconArchive = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="5" rx="1"/><path d="M4 9v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9"/><path d="M10 13h4"/></svg>';
const iconRestore = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg>';
const iconTrash = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>';
const iconStatement = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8"/><path d="M8 17h5"/></svg>';

/* -------------------------------------------------------------------------
 | Create / edit
 | ---------------------------------------------------------------------- */

function openForm(party = null) {
    const form = $('#party-form');
    const editing = party !== null;

    clearFormErrors(form);
    form.reset();

    $('#party-modal-title').textContent = editing ? 'Edit party' : 'New party';

    form.elements.id.value = editing ? party.id : '';
    form.elements.name.value = editing ? party.name : '';
    form.elements.gstin.value = editing ? (party.gstin ?? '') : '';
    form.elements.phone.value = editing ? (party.phone ?? '') : '';
    form.elements.email.value = editing ? (party.email ?? '') : '';
    form.elements.address.value = editing ? (party.address ?? '') : '';
    form.elements.notes.value = editing ? (party.notes ?? '') : '';

    const roles = editing ? (party.roles ?? []) : ['customer'];
    $$('#party-roles input[name="roles"]').forEach((box) => {
        box.checked = roles.includes(box.value);
    });

    showStateHint(form.elements.gstin.value);
    showModal('#party-modal');
}

/** The state code the GSTIN implies, shown as it is typed. */
function showStateHint(gstin) {
    const hint = $('#party-state-hint');
    const code = String(gstin ?? '').trim().slice(0, 2);

    hint.textContent = /^\d{2}$/.test(code)
        ? `State code ${code}. Bills to this party will be inter-state unless it matches your workshop's.`
        : 'Optional. The first two digits set the state, which decides CGST/SGST or IGST.';
}

function selectedRoles(form) {
    return $$('input[name="roles"]', form).filter((box) => box.checked).map((box) => box.value);
}

function validate(form) {
    const errors = {};
    const name = form.elements.name.value.trim();

    if (name.length < 2) errors.name = ['The name must be at least 2 characters.'];
    else if (name.length > 150) errors.name = ['The name may not exceed 150 characters.'];

    if (!selectedRoles(form).length) {
        errors.roles = ['Say whether this party is a customer, a vendor, or both.'];
    }

    const gstin = form.elements.gstin.value.trim().toUpperCase();

    // Checked here as well as server-side so the shape is explained before a
    // round trip. The server is still the authority.
    if (gstin && !/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(gstin)) {
        errors.gstin = ['That does not look like a GSTIN — 15 characters: 2 digits, a PAN, then 3 more.'];
    }

    return Object.keys(errors).length ? errors : null;
}

async function submitForm(event) {
    event.preventDefault();

    const form = event.target;
    const id = form.elements.id.value;
    const editing = id !== '';

    clearFormErrors(form);

    const errors = validate(form);

    if (errors) {
        showFormErrors(form, { fields: errors, message: 'Please correct the highlighted fields.' });

        return;
    }

    const payload = {
        name: form.elements.name.value.trim(),
        roles: selectedRoles(form),
        gstin: form.elements.gstin.value.trim().toUpperCase() || null,
        phone: form.elements.phone.value.trim() || null,
        email: form.elements.email.value.trim() || null,
        address: form.elements.address.value.trim() || null,
        notes: form.elements.notes.value.trim() || null,
    };

    setSubmitting(form, true);

    try {
        const response = await auth.call(editing ? `/parties/${id}` : '/parties', {
            method: editing ? 'PATCH' : 'POST',
            body: payload,
        });

        hideModal('#party-modal');
        toast(editing ? 'Party updated.' : 'Party created.');

        // A shared GSTIN is legitimate for a second branch and a duplicate the
        // rest of the time, so it is reported after the save rather than
        // blocking it — the user can still merge the two while it is fresh.
        (response.meta?.warnings ?? []).forEach((warning) => toast(warning.message, 'info'));

        loadParties();
    } catch (error) {
        showFormErrors(form, error);
    } finally {
        setSubmitting(form, false);
    }
}

/* -------------------------------------------------------------------------
 | Archive / delete
 | ---------------------------------------------------------------------- */

async function toggleArchived(id, name, currentlyActive) {
    if (currentlyActive) {
        const confirmed = await confirmAction({
            title: 'Archive party',
            body: `${name} will stop appearing when you choose a party on a transaction. Everything already `
                + 'posted stays exactly as it is, and their statement stays readable. You can restore them at any time.',
            confirmLabel: 'Archive party',
        });

        if (!confirmed) return;
    }

    try {
        await auth.call(`/parties/${id}`, { method: 'PATCH', body: { is_active: !currentlyActive } });

        toast(currentlyActive ? 'Party archived.' : 'Party restored.');
        loadParties();
    } catch (error) {
        toast(error.message, 'error');
    }
}

async function deleteParty(id, name) {
    const confirmed = await confirmAction({
        title: 'Delete party',
        body: `${name} will be removed completely. This is only possible while they have no transactions at `
            + 'all — once they appear in the books, archive them instead so their entries keep their name.',
        confirmLabel: 'Delete party',
    });

    if (!confirmed) return;

    try {
        await auth.call(`/parties/${id}`, { method: 'DELETE' });

        toast('Party deleted.');
        loadParties();
    } catch (error) {
        // PARTY_IN_USE explains itself and names the alternative, so it is
        // shown as-is rather than replaced with something generic.
        toast(error.message, 'error');
    }
}

/* -------------------------------------------------------------------------
 | The statement
 | ---------------------------------------------------------------------- */

async function openLedger(partyId, name) {
    state.ledger = { partyId, page: 1, lastPage: 1 };

    $('#party-ledger-title').textContent = name;
    $('#party-ledger-subtitle').textContent = 'Every entry that moved their position, oldest first.';
    $('#party-ledger-position').innerHTML = '';
    $('#party-ledger-rows').innerHTML = tableMessage(5, 'Loading statement…');

    showModal('#party-ledger-modal');

    loadLedger();
}

async function loadLedger() {
    const { partyId, page } = state.ledger;

    try {
        const payload = await auth.call(
            `/parties/${partyId}/ledger?per_page=${LEDGER_PAGE_SIZE}&page=${page}`
        );

        renderPosition(payload.meta);
        renderLedger(payload.data, payload.meta);
    } catch (error) {
        $('#party-ledger-rows').innerHTML = tableMessage(5, error.message, 'error');
        $('#party-ledger-summary').textContent = '';
    }
}

/**
 * Receivable and payable side by side, plus the net.
 *
 * The net is signed towards the workshop — positive means they owe you — which
 * is stated in words rather than left to a minus sign, because a minus sign in
 * front of a balance is exactly the thing people read the wrong way round.
 */
function renderPosition(meta) {
    const { receivable, payable, net } = meta.outstanding;
    const owesUs = !net.startsWith('-');

    $('#party-ledger-position').innerHTML = `
        <div class="flex flex-wrap items-center gap-x-8 gap-y-3">
            <div>
                <p class="text-xs uppercase tracking-wide text-muted-foreground">Receivable</p>
                <p class="mt-0.5 font-mono text-lg font-semibold">${esc(formatMoney(receivable))}</p>
            </div>
            <div>
                <p class="text-xs uppercase tracking-wide text-muted-foreground">Payable</p>
                <p class="mt-0.5 font-mono text-lg font-semibold">${esc(formatMoney(payable))}</p>
            </div>
            <div class="border-l border-border pl-8">
                <p class="text-xs uppercase tracking-wide text-muted-foreground">
                    ${isZeroAmount(net) ? 'Settled' : (owesUs ? 'They owe you' : 'You owe them')}
                </p>
                <p class="mt-0.5 font-mono text-lg font-semibold ${isZeroAmount(net) ? '' : (owesUs ? 'text-emerald-700' : 'text-rose-700')}">
                    ${esc(formatMoney(net.replace(/^-/, '')))}
                </p>
            </div>
        </div>`;
}

function renderLedger(entries, meta) {
    const body = $('#party-ledger-rows');

    if (!entries.length) {
        body.innerHTML = tableMessage(5, 'Nothing has been posted against this party yet.');
        $('#party-ledger-summary').textContent = '';
        setLedgerPager(1, 1);

        return;
    }

    const opening = `
        <tr class="border-b border-border bg-secondary/30 text-[0.8125rem]">
            <td class="px-6 py-2 text-muted-foreground" colspan="4">Brought forward</td>
            <td class="px-6 py-2 text-right font-mono font-semibold">${esc(formatMoney(meta.opening_balance))}</td>
        </tr>`;

    body.innerHTML = opening + entries.map((entry) => `
        <tr class="border-b border-border">
            <td class="px-6 py-2.5 text-[0.8125rem] text-muted-foreground">${esc(formatDate(entry.date))}</td>
            <td class="px-4 py-2.5 text-[0.8125rem]">
                <span class="font-medium">${esc(entry.account?.name ?? '')}</span>
                ${entry.memo ? `<span class="ml-2 text-muted-foreground">${esc(entry.memo)}</span>` : ''}
            </td>
            <td class="px-4 py-2.5 text-right font-mono text-[0.8125rem]">
                ${isZeroAmount(entry.debit) ? '' : esc(formatMoney(entry.debit))}
            </td>
            <td class="px-4 py-2.5 text-right font-mono text-[0.8125rem]">
                ${isZeroAmount(entry.credit) ? '' : esc(formatMoney(entry.credit))}
            </td>
            <td class="px-6 py-2.5 text-right font-mono text-[0.8125rem] font-semibold">
                ${esc(formatMoney(entry.running_balance))}
            </td>
        </tr>`).join('');

    const pagination = meta.pagination ?? {};
    state.ledger.lastPage = pagination.last_page ?? 1;

    $('#party-ledger-summary').textContent =
        `${pagination.total ?? entries.length} entries · closing ${formatMoney(meta.closing_balance)}`;

    setLedgerPager(pagination.current_page ?? 1, state.ledger.lastPage);
}

function setLedgerPager(current, last) {
    $('#ledger-prev').disabled = current <= 1;
    $('#ledger-next').disabled = current >= last;
}

/* -------------------------------------------------------------------------
 | Boot
 | ---------------------------------------------------------------------- */

export default async function initParties() {
    await loadParties();

    $('#new-party')?.addEventListener('click', () => openForm());
    $('#party-form').addEventListener('submit', submitForm);

    $('#party-gstin').addEventListener('input', (event) => showStateHint(event.target.value));

    $('#filter-search').addEventListener('input', debounce((event) => {
        state.search = event.target.value.trim();
        state.page = 1;
        loadParties();
    }, 350));

    $('#filter-role').addEventListener('change', (event) => {
        state.role = event.target.value;
        state.page = 1;
        loadParties();
    });

    $('#filter-status').addEventListener('change', (event) => {
        state.isActive = event.target.value;
        state.page = 1;
        loadParties();
    });

    $('#page-prev').addEventListener('click', () => {
        if (state.page > 1) { state.page -= 1; loadParties(); }
    });

    $('#page-next').addEventListener('click', () => {
        if (state.page < state.lastPage) { state.page += 1; loadParties(); }
    });

    $('#ledger-prev').addEventListener('click', () => {
        if (state.ledger.page > 1) { state.ledger.page -= 1; loadLedger(); }
    });

    $('#ledger-next').addEventListener('click', () => {
        if (state.ledger.page < state.ledger.lastPage) { state.ledger.page += 1; loadLedger(); }
    });

    $('#parties-body').addEventListener('click', async (event) => {
        const edit = event.target.closest('[data-edit]');
        const toggle = event.target.closest('[data-toggle]');
        const remove = event.target.closest('[data-delete]');
        const ledger = event.target.closest('[data-ledger]');

        if (edit) {
            const { data } = await auth.call(`/parties/${edit.dataset.edit}`);
            openForm(data);
        }

        if (toggle) {
            toggleArchived(toggle.dataset.toggle, toggle.dataset.name, toggle.dataset.active === '1');
        }

        if (remove) {
            deleteParty(remove.dataset.delete, remove.dataset.name);
        }

        if (ledger) {
            openLedger(ledger.dataset.ledger, ledger.dataset.name);
        }
    });
}
