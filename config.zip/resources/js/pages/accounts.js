import auth from '../auth-client';
import { can } from '../permissions';
import {
    $, clearFormErrors, confirmAction, debounce, esc,
    hideModal, setSubmitting, showFormErrors, showModal, toast,
} from '../ui';

/**
 * The chart of accounts is small by nature — fifteen system accounts plus
 * whatever the workshop adds — so the whole thing is fetched at once and
 * rendered as five typed blocks rather than a paginated flat list. That is how
 * an accountant reads a chart, and it makes the code bands self-evident.
 */
const PAGE_SIZE = 200;

/** Canonical statement order, not alphabetical. */
const TYPE_ORDER = ['asset', 'liability', 'equity', 'income', 'expense'];

const state = {
    search: '',
    type: '',
    isActive: '1',
    types: {},      // { asset: {label, code_range, normal_balance, …} }
    accounts: [],
};

/* -------------------------------------------------------------------------
 | Data
 | ---------------------------------------------------------------------- */

/** Type metadata comes from the server so the bands are never duplicated here. */
async function loadTypes() {
    if (Object.keys(state.types).length) return;

    const { data } = await auth.call('/accounts/types');

    state.types = Object.fromEntries(data.map((type) => [type.value, type]));
}

async function loadAccounts() {
    const host = $('#accounts-groups');
    host.innerHTML = message('Loading accounts…');

    const params = new URLSearchParams({ per_page: PAGE_SIZE });
    if (state.search) params.set('search', state.search);
    if (state.type) params.set('type', state.type);
    if (state.isActive !== '') params.set('is_active', state.isActive);

    try {
        const payload = await auth.call(`/accounts?${params}`);

        state.accounts = payload.data;
        render(payload.data, payload.meta?.pagination);
    } catch (error) {
        // A platform super-admin holds every permission but belongs to no
        // workshop, so they can reach this page by typing the URL and there is
        // nothing to show them. That is not an error on their part — say so
        // plainly instead of painting the page red.
        host.innerHTML = error.code === 'NO_WORKSPACE'
            ? notice(
                'No workshop selected',
                'Your account administers the platform rather than a single workshop, so it has no chart of '
                + 'accounts of its own. Open a workshop from the workspaces list to see its books.',
            )
            : message(error.message, 'error');

        $('#accounts-summary').textContent = '';
        $('#new-account')?.classList.add('hidden');
    }
}

/* -------------------------------------------------------------------------
 | Rendering
 | ---------------------------------------------------------------------- */

function message(text, tone = 'muted') {
    const color = tone === 'error' ? 'text-rose-600' : 'text-muted-foreground';

    return `<div class="surface px-4 py-12 text-center text-sm ${color}">${esc(text)}</div>`;
}

/** An explanatory empty state — a situation, not a failure. */
function notice(title, body) {
    return `
        <div class="surface px-6 py-12 text-center">
            <p class="text-sm font-semibold text-foreground">${esc(title)}</p>
            <p class="mx-auto mt-1.5 max-w-md text-[0.8125rem] text-muted-foreground">${esc(body)}</p>
        </div>`;
}

function render(accounts, pagination) {
    const host = $('#accounts-groups');

    if (!accounts.length) {
        host.innerHTML = message('No accounts match these filters.');
        $('#accounts-summary').textContent = '';

        return;
    }

    const grouped = TYPE_ORDER
        .map((type) => [type, accounts.filter((account) => account.type === type)])
        .filter(([, rows]) => rows.length);

    host.innerHTML = grouped.map(([type, rows]) => renderGroup(type, rows)).join('');

    const total = pagination?.total ?? accounts.length;
    const truncated = pagination && pagination.total > accounts.length;

    $('#accounts-summary').textContent = truncated
        ? `Showing ${accounts.length} of ${total} accounts — narrow the filters to see the rest.`
        : `${total} account${total === 1 ? '' : 's'}.`;
}

function renderGroup(type, rows) {
    const meta = state.types[type] ?? {};
    const [low, high] = meta.code_range ?? [];
    const side = meta.normal_balance === 'credit' ? 'Credit' : 'Debit';

    return `
        <section class="surface overflow-hidden">
            <header class="flex flex-wrap items-center justify-between gap-2 border-b border-border bg-secondary/40 px-4 py-3">
                <div class="flex items-center gap-2">
                    <h3 class="text-sm font-bold text-foreground">${esc(meta.label ?? type)}</h3>
                    <span class="badge bg-muted text-secondary-foreground">${rows.length}</span>
                </div>
                <div class="flex items-center gap-3 text-xs text-muted-foreground">
                    ${low ? `<span class="font-mono">${low}–${high}</span>` : ''}
                    <span>Increases on the <strong class="font-semibold text-secondary-foreground">${side}</strong> side</span>
                </div>
            </header>

            <div class="overflow-x-auto">
                <table class="w-full min-w-[680px] border-collapse">
                    <thead class="sr-only">
                        <tr>
                            <th>Code</th><th>Account</th><th>Normal balance</th><th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>${rows.map(renderRow).join('')}</tbody>
                </table>
            </div>
        </section>`;
}

function renderRow(account) {
    const mayUpdate = can('UPDATE', 'ACCOUNTS');
    const locked = account.is_system;
    const side = account.normal_balance === 'credit' ? 'Cr' : 'Dr';

    // System accounts keep a disabled control rather than none, so the reason
    // stays visible instead of the option silently vanishing.
    const archiveButton = locked
        ? `<button type="button" class="btn btn-ghost btn-icon opacity-40" disabled
                   title="System accounts cannot be archived — the posting engine depends on them"
                   aria-label="Archive (disabled)">${iconArchive}</button>`
        : `<button type="button" class="btn btn-ghost btn-icon" data-toggle="${account.id}"
                   data-name="${esc(account.name)}" data-active="${account.is_active ? '1' : '0'}"
                   title="${account.is_active ? 'Archive account' : 'Restore account'}"
                   aria-label="${account.is_active ? 'Archive account' : 'Restore account'}">${account.is_active ? iconArchive : iconRestore}</button>`;

    return `
        <tr class="border-t border-border transition hover:bg-secondary/60 ${account.is_active ? '' : 'opacity-60'}">
            <td class="table-cell w-20 font-mono text-[0.8125rem] text-muted-foreground">${esc(account.code)}</td>

            <td class="table-cell">
                <div class="flex items-center gap-2">
                    <span class="font-semibold">${esc(account.name)}</span>
                    ${locked ? '<span class="badge bg-accent text-accent-foreground">System</span>' : ''}
                    ${account.is_active ? '' : '<span class="badge bg-muted text-muted-foreground">Archived</span>'}
                </div>
                ${account.description
                    ? `<div class="mt-0.5 truncate text-[0.8125rem] text-muted-foreground">${esc(account.description)}</div>`
                    : ''}
            </td>

            <td class="table-cell w-24 text-[0.8125rem] text-muted-foreground">${side}</td>

            <td class="table-cell w-24">
                <div class="flex justify-end gap-1">
                    ${mayUpdate ? `<button type="button" class="btn btn-ghost btn-icon" data-edit="${account.id}" title="Edit account" aria-label="Edit account">${iconPencil}</button>` : ''}
                    ${mayUpdate ? archiveButton : ''}
                </div>
            </td>
        </tr>`;
}

const iconPencil = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M21.17 6.83a2.83 2.83 0 0 0-4-4L3.5 16.5 2 22l5.5-1.5z"/><path d="m15 5 4 4"/></svg>';
const iconArchive = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="5" rx="1"/><path d="M4 9v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9"/><path d="M10 13h4"/></svg>';
const iconRestore = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg>';

/* -------------------------------------------------------------------------
 | Create / edit
 | ---------------------------------------------------------------------- */

/**
 * The lowest unused code in a type's band, so the common case needs no
 * thought. Steps by 10 to leave room for related accounts to sit together.
 */
function suggestCode(type) {
    const meta = state.types[type];
    if (!meta) return '';

    const [low, high] = meta.code_range;
    const taken = new Set(state.accounts.map((account) => Number(account.code)));

    for (let code = low + 10; code <= high; code += 10) {
        if (!taken.has(code)) return String(code);
    }

    return '';
}

function applyTypeHints(type, { suggest = false } = {}) {
    const meta = state.types[type];
    const codeInput = $('#account-code');

    if (!meta) {
        $('#account-type-hint').textContent = 'Decides which side increases the account.';
        $('#account-code-hint').textContent = 'Four digits, inside the band for the chosen type.';

        return;
    }

    const [low, high] = meta.code_range;
    const side = meta.normal_balance === 'credit' ? 'credit' : 'debit';

    $('#account-type-hint').textContent =
        `Increases on the ${side} side · ${meta.is_balance_sheet ? 'Balance sheet' : 'Profit & loss'}`;
    $('#account-code-hint').textContent = `Must be between ${low} and ${high}.`;

    if (suggest && !codeInput.value) codeInput.value = suggestCode(type);
}

async function openForm(account = null) {
    const form = $('#account-form');
    const editing = account !== null;
    const locked = editing && account.is_system;

    await loadTypes();

    clearFormErrors(form);
    form.reset();

    $('#account-modal-title').textContent = editing ? 'Edit account' : 'New account';
    $('#account-system-note').classList.toggle('hidden', !locked);
    $('#account-system-note').classList.toggle('flex', locked);

    form.elements.id.value = editing ? account.id : '';
    form.elements.name.value = editing ? account.name : '';
    form.elements.description.value = editing ? (account.description ?? '') : '';
    form.elements.code.value = editing ? account.code : '';
    form.elements.type.value = editing ? account.type : '';

    // Type is immutable for every account, system or not: reclassifying would
    // move every journal entry already posted against it onto a different
    // financial statement. Code is fixed for system accounts only.
    form.elements.type.disabled = editing;
    form.elements.code.disabled = locked;

    applyTypeHints(editing ? account.type : '');

    showModal('#account-modal');
}

function validate(form, editing) {
    const errors = {};

    if (!editing && !form.elements.type.value) {
        errors.type = ['Choose an account type.'];
    }

    const code = form.elements.code.value.trim();

    if (!form.elements.code.disabled) {
        if (!/^\d{4}$/.test(code)) {
            errors.code = ['An account code is exactly four digits.'];
        } else {
            // Checked here as well as server-side so the band is explained
            // before a round trip, not after a 409.
            const type = form.elements.type.value;
            const meta = state.types[type];

            if (meta) {
                const [low, high] = meta.code_range;

                if (Number(code) < low || Number(code) > high) {
                    errors.code = [`A ${type} account must be numbered between ${low} and ${high}.`];
                }
            }
        }
    }

    const name = form.elements.name.value.trim();

    if (name.length < 2) errors.name = ['The account name must be at least 2 characters.'];
    else if (name.length > 120) errors.name = ['The account name may not exceed 120 characters.'];

    if (form.elements.description.value.trim().length > 255) {
        errors.description = ['The description may not exceed 255 characters.'];
    }

    return Object.keys(errors).length ? errors : null;
}

async function submitForm(event) {
    event.preventDefault();

    const form = event.target;
    const id = form.elements.id.value;
    const editing = id !== '';

    clearFormErrors(form);

    const errors = validate(form, editing);

    if (errors) {
        showFormErrors(form, { fields: errors, message: 'Please correct the highlighted fields.' });

        return;
    }

    const payload = {
        name: form.elements.name.value.trim(),
        description: form.elements.description.value.trim() || null,
    };

    // A disabled input is not submitted, and the server rejects a system
    // account's code outright — so it is only ever sent when editable.
    if (!form.elements.code.disabled) payload.code = form.elements.code.value.trim();
    if (!editing) payload.type = form.elements.type.value;

    setSubmitting(form, true);

    try {
        await auth.call(editing ? `/accounts/${id}` : '/accounts', {
            method: editing ? 'PATCH' : 'POST',
            body: payload,
        });

        hideModal('#account-modal');
        toast(editing ? 'Account updated.' : 'Account created.');
        loadAccounts();
    } catch (error) {
        showFormErrors(form, error);
    } finally {
        setSubmitting(form, false);
    }
}

/* -------------------------------------------------------------------------
 | Archive / restore
 | ---------------------------------------------------------------------- */

async function toggleArchived(id, name, currentlyActive) {
    if (currentlyActive) {
        const confirmed = await confirmAction({
            title: 'Archive account',
            body: `${name} will stop appearing when choosing an account. Nothing already posted to it changes — `
                + 'accounts are never deleted, so its history stays intact. You can restore it at any time.',
            confirmLabel: 'Archive account',
        });

        if (!confirmed) return;
    }

    try {
        await auth.call(`/accounts/${id}`, {
            method: 'PATCH',
            body: { is_active: !currentlyActive },
        });

        toast(currentlyActive ? 'Account archived.' : 'Account restored.');
        loadAccounts();
    } catch (error) {
        toast(error.message, 'error');
    }
}

/* -------------------------------------------------------------------------
 | Boot
 | ---------------------------------------------------------------------- */

export default async function initAccounts() {
    await loadTypes();
    await loadAccounts();

    $('#new-account')?.addEventListener('click', () => openForm());
    $('#account-form').addEventListener('submit', submitForm);

    $('#account-type').addEventListener('change', (event) => {
        applyTypeHints(event.target.value, { suggest: true });
    });

    $('#filter-search').addEventListener('input', debounce((event) => {
        state.search = event.target.value.trim();
        loadAccounts();
    }, 350));

    $('#filter-type').addEventListener('change', (event) => {
        state.type = event.target.value;
        loadAccounts();
    });

    $('#filter-status').addEventListener('change', (event) => {
        state.isActive = event.target.value;
        loadAccounts();
    });

    $('#accounts-groups').addEventListener('click', async (event) => {
        const editButton = event.target.closest('[data-edit]');
        const toggleButton = event.target.closest('[data-toggle]');

        if (editButton) {
            const { data } = await auth.call(`/accounts/${editButton.dataset.edit}`);
            openForm(data);
        }

        if (toggleButton) {
            toggleArchived(
                toggleButton.dataset.toggle,
                toggleButton.dataset.name,
                toggleButton.dataset.active === '1',
            );
        }
    });
}
