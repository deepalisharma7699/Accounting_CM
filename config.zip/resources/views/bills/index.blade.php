@extends('layouts.app')

@section('title', 'Bills')
@section('page', 'bills')

@section('content')

<header class="mb-6 flex flex-wrap items-start justify-between gap-4">
    <div>
        <h2 class="text-2xl font-bold tracking-tight text-foreground">Bills</h2>
        <p class="mt-1.5 text-[0.9375rem] text-muted-foreground">
            What was sold, what was bought and what it cost to keep the doors open. Tax follows the item's
            HSN code and the two state codes; cost follows the shelf at the moment of sale.
        </p>
    </div>

    <div class="flex flex-wrap gap-2">
        <button type="button" id="new-sale" class="btn btn-primary hidden"
                data-requires-permission="WRITE:TRANSACTIONS">
            <x-icon name="receipt" :size="17" />
            New sale
        </button>
        <button type="button" id="new-purchase" class="btn btn-secondary hidden"
                data-requires-permission="WRITE:TRANSACTIONS">
            <x-icon name="shopping-cart" :size="17" />
            New purchase
        </button>
        <button type="button" id="new-expense" class="btn btn-secondary hidden"
                data-requires-permission="WRITE:TRANSACTIONS">
            <x-icon name="credit-card" :size="17" />
            New expense
        </button>
    </div>
</header>

<div class="surface mb-4 flex flex-wrap items-center gap-3 p-3">
    <select id="filter-type" class="field-input w-auto min-w-44" aria-label="Filter by kind">
        <option value="">Sales, purchases and expenses</option>
        <option value="sale">Sales</option>
        <option value="purchase">Purchases</option>
        <option value="expense">Expenses</option>
    </select>

    <select id="filter-status" class="field-input w-auto min-w-40" aria-label="Filter by status">
        <option value="">Any status</option>
        @foreach (\App\Enums\TransactionStatus::cases() as $status)
            <option value="{{ $status->value }}">{{ $status->label() }}</option>
        @endforeach
    </select>

    <label class="flex items-center gap-2 text-[0.8125rem] text-muted-foreground">
        From
        <input type="date" id="filter-from" class="field-input w-auto" aria-label="From date">
    </label>

    <label class="flex items-center gap-2 text-[0.8125rem] text-muted-foreground">
        To
        <input type="date" id="filter-to" class="field-input w-auto" aria-label="To date">
    </label>

    <button type="button" id="clear-filters" class="btn btn-ghost btn-sm">Clear</button>
</div>

<div class="surface overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full min-w-[760px] border-collapse">
            <thead>
                <tr class="border-b border-border bg-secondary/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th class="px-4 py-3 font-semibold">Date</th>
                    <th class="px-4 py-3 font-semibold">Kind</th>
                    <th class="px-4 py-3 font-semibold">Party</th>
                    <th class="px-4 py-3 font-semibold">Notes</th>
                    <th class="px-4 py-3 text-right font-semibold">Total</th>
                    <th class="px-4 py-3 font-semibold">Status</th>
                </tr>
            </thead>
            <tbody id="bills-body"></tbody>
        </table>
    </div>

    <div class="flex flex-wrap items-center justify-between gap-3 border-t border-border px-4 py-3">
        <p id="bills-summary" class="text-[0.8125rem] text-muted-foreground"></p>

        <div class="flex gap-2">
            <button type="button" id="page-prev" class="btn btn-secondary btn-sm" disabled>Previous</button>
            <button type="button" id="page-next" class="btn btn-secondary btn-sm" disabled>Next</button>
        </div>
    </div>
</div>

{{-- The bill, opened over the list. Shows the document — items, tax, totals —
     and, for a sale, what it made. The margin is derived on read from the stock
     movement behind each line, so it is answerable long after the bill was
     posted, which is when "why is this month's margin down" is actually asked. --}}
<div id="bill-modal" class="modal-backdrop hidden" data-modal role="dialog" aria-modal="true"
     aria-labelledby="bill-modal-title">
    <div class="modal-panel max-w-4xl">
        <header class="flex items-start justify-between gap-4 border-b border-border px-5 py-4">
            <div>
                <h2 class="text-base font-bold text-foreground" id="bill-modal-title">Bill</h2>
                <p class="mt-0.5 text-[0.8125rem] text-muted-foreground" id="bill-modal-subtitle"></p>
            </div>
            <button type="button" class="btn btn-ghost btn-icon" data-modal-close aria-label="Close">
                <x-icon name="x" :size="18" />
            </button>
        </header>

        <div class="max-h-[70vh] overflow-y-auto" id="bill-modal-body"></div>
    </div>
</div>

{{-- One form for a sale and a purchase: the payload is identical and the
     direction is the route, not a field — the same choice the API makes. --}}
<div id="bill-form-modal" class="modal-backdrop hidden" data-modal role="dialog" aria-modal="true"
     aria-labelledby="bill-form-title">
    <div class="modal-panel max-w-4xl">
        <form id="bill-form" novalidate>
            <header class="border-b border-border px-5 py-4">
                <h2 class="text-base font-bold text-foreground" id="bill-form-title">New sale</h2>
                <p class="mt-0.5 text-[0.8125rem] text-muted-foreground" id="bill-form-hint"></p>
            </header>

            <div class="max-h-[60vh] space-y-4 overflow-y-auto px-5 py-4">
                <div class="grid gap-4 sm:grid-cols-3">
                    <label class="field">
                        <span class="field-label">Date</span>
                        <input type="date" name="date" class="field-input" required>
                        <span class="field-error" data-error="date"></span>
                    </label>

                    <label class="field sm:col-span-2">
                        <span class="field-label" id="bill-party-label">Customer</span>
                        <select name="party_id" class="field-input" required>
                            <option value="">Choose…</option>
                        </select>
                        <span class="field-error" data-error="party_id"></span>
                    </label>
                </div>

                <label class="field">
                    <span class="field-label">Notes</span>
                    <input type="text" name="notes" class="field-input" maxlength="500"
                           placeholder="Rewind for pump motor, site 4">
                    <span class="field-error" data-error="notes"></span>
                </label>

                <div id="bill-lines" class="space-y-3"></div>

                <button type="button" id="add-bill-line" class="btn btn-secondary btn-sm">
                    <x-icon name="plus" :size="15" />
                    Add a line
                </button>

                <div class="field-error" data-error="items"></div>

                {{-- Optional, unlike a settlement's. A sale on thirty-day terms
                     carries none; a counter sale carries the whole invoice. --}}
                <div class="border-t border-border pt-4">
                    <h3 class="text-sm font-semibold text-foreground" id="bill-payment-heading">Collected now</h3>
                    <p class="mt-0.5 text-[0.8125rem] text-muted-foreground">
                        Leave empty for a bill on credit. It may not come to more than the invoice — the rest is
                        settled later with a receipt.
                    </p>

                    <div id="bill-payments" class="mt-3 space-y-3"></div>

                    <button type="button" id="add-bill-payment" class="btn btn-ghost btn-sm mt-2">
                        <x-icon name="plus" :size="15" />
                        Add a payment
                    </button>

                    <div class="field-error" data-error="payments"></div>
                </div>

                <div class="rounded-[10px] bg-secondary/40 px-4 py-3 text-sm" id="bill-totals"></div>
            </div>

            <footer class="flex items-center justify-end gap-2 border-t border-border px-5 py-4">
                <button type="button" class="btn btn-ghost" data-modal-close>Cancel</button>
                <button type="submit" class="btn btn-secondary" data-post="0">Save as draft</button>
                <button type="submit" class="btn btn-primary" data-post="1">Post the bill</button>
            </footer>
        </form>
    </div>
</div>

{{-- An expense is a different kind of money and gets a different form: it costs
     the workshop to be open, and nothing on it is bought to sell. --}}
<div id="expense-modal" class="modal-backdrop hidden" data-modal role="dialog" aria-modal="true"
     aria-labelledby="expense-title">
    <div class="modal-panel max-w-2xl">
        <form id="expense-form" novalidate>
            <header class="border-b border-border px-5 py-4">
                <h2 class="text-base font-bold text-foreground" id="expense-title">New expense</h2>
                <p class="mt-0.5 text-[0.8125rem] text-muted-foreground">
                    Rent, electricity, a courier, the tea. Anything bought to sell or to fit is a purchase.
                </p>
            </header>

            <div class="max-h-[60vh] space-y-4 overflow-y-auto px-5 py-4">
                <div class="grid gap-4 sm:grid-cols-2">
                    <label class="field">
                        <span class="field-label">Date</span>
                        <input type="date" name="date" class="field-input" required>
                        <span class="field-error" data-error="date"></span>
                    </label>

                    <label class="field">
                        <span class="field-label">Account</span>
                        <select name="account_id" class="field-input">
                            <option value="">Misc Expense</option>
                        </select>
                        <span class="field-error" data-error="account_id"></span>
                    </label>
                </div>

                <div class="grid gap-4 sm:grid-cols-2">
                    <label class="field">
                        <span class="field-label">Amount before tax</span>
                        <input type="text" name="amount" class="field-input font-mono" inputmode="decimal" required>
                        <span class="field-error" data-error="amount"></span>
                    </label>

                    <label class="field">
                        <span class="field-label">Claimable GST</span>
                        <input type="text" name="gst_amount" class="field-input font-mono" inputmode="decimal"
                               placeholder="Leave blank where none is claimable">
                        <span class="field-error" data-error="gst_amount"></span>
                    </label>
                </div>

                <label class="field">
                    <span class="field-label">Notes</span>
                    <input type="text" name="notes" class="field-input" maxlength="500"
                           placeholder="March electricity">
                    <span class="field-error" data-error="notes"></span>
                </label>

                <div class="border-t border-border pt-4">
                    <h3 class="text-sm font-semibold text-foreground">Paid by</h3>
                    <div id="expense-payments" class="mt-3 space-y-3"></div>

                    <button type="button" id="add-expense-payment" class="btn btn-ghost btn-sm mt-2">
                        <x-icon name="plus" :size="15" />
                        Add a payment
                    </button>

                    <div class="field-error" data-error="payments"></div>
                </div>
            </div>

            <footer class="flex items-center justify-end gap-2 border-t border-border px-5 py-4">
                <button type="button" class="btn btn-ghost" data-modal-close>Cancel</button>
                <button type="submit" class="btn btn-primary">Record the expense</button>
            </footer>
        </form>
    </div>
</div>

@include('partials.confirm-modal')

@endsection
