@extends('layouts.app')

@section('title', 'Chart of Accounts')
@section('page', 'accounts')

@section('content')

<header class="mb-6 flex flex-wrap items-start justify-between gap-4">
    <div>
        <h2 class="text-2xl font-bold tracking-tight text-foreground">Chart of Accounts</h2>
        <p class="mt-1.5 text-[0.9375rem] text-muted-foreground">
            Every ledger in the workshop. The fifteen system accounts are created with the workspace
            and cannot be renumbered or archived — add your own alongside them.
        </p>
    </div>

    <button type="button" id="new-account" class="btn btn-primary hidden"
            data-requires-permission="WRITE:ACCOUNTS">
        <x-icon name="plus" :size="17" />
        New account
    </button>
</header>

<div class="surface mb-4 flex flex-wrap items-center gap-3 p-3">
    <div class="relative min-w-56 flex-1">
        <span class="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
            <x-icon name="search" :size="17" />
        </span>
        <input type="search" id="filter-search" class="field-input pl-9"
               placeholder="Search by name or code…" aria-label="Search accounts">
    </div>

    <select id="filter-type" class="field-input w-auto min-w-40" aria-label="Filter by type">
        <option value="">All types</option>
        @foreach (\App\Enums\AccountType::cases() as $type)
            <option value="{{ $type->value }}">{{ $type->label() }}</option>
        @endforeach
    </select>

    <select id="filter-status" class="field-input w-auto min-w-40" aria-label="Filter by status">
        <option value="1">Active</option>
        <option value="0">Archived</option>
        <option value="">Active &amp; archived</option>
    </select>
</div>

{{-- Grouped by type rather than paginated: a chart of accounts is small by
     nature, and an accountant reads it as five blocks, not as a flat list. --}}
<div id="accounts-groups" class="space-y-4"></div>

<p id="accounts-summary" class="mt-4 text-[0.8125rem] text-muted-foreground"></p>

{{-- Create / edit --}}
<div id="account-modal" class="modal-backdrop hidden" data-modal role="dialog" aria-modal="true"
     aria-labelledby="account-modal-title">
    <div class="modal-panel max-w-lg">
        <form id="account-form" novalidate>
            <input type="hidden" name="id">

            <div class="flex items-center justify-between border-b border-border px-6 py-4">
                <h2 id="account-modal-title" class="text-base font-bold text-foreground">New account</h2>
                <button type="button" class="btn btn-ghost btn-icon" data-modal-close aria-label="Close">
                    <x-icon name="x" :size="18" />
                </button>
            </div>

            <div class="max-h-[65vh] space-y-4 overflow-y-auto px-6 py-5">
                <p class="hidden rounded-[10px] border border-rose-200 bg-rose-50 px-3.5 py-3 text-[0.8125rem] text-rose-700"
                   data-form-banner role="alert"></p>

                {{-- Shown for system accounts, whose structure is fixed. --}}
                <p id="account-system-note"
                   class="hidden items-start gap-2 rounded-[10px] border border-amber-200 bg-amber-50/60 px-3.5 py-3
                          text-[0.8125rem] text-amber-800">
                    <x-icon name="lock" :size="16" class="mt-0.5 shrink-0" />
                    <span>
                        This is a system account. You may rename it and edit its description — the posting
                        engine finds it by an internal key, not by its name — but its number and type are fixed.
                    </span>
                </p>

                <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                        <label for="account-type" class="field-label">Type</label>
                        <select id="account-type" name="type" class="field-input" required>
                            <option value="">Select a type…</option>
                            @foreach (\App\Enums\AccountType::cases() as $type)
                                <option value="{{ $type->value }}">{{ $type->label() }}</option>
                            @endforeach
                        </select>
                        <p class="mt-1.5 text-xs text-muted-foreground" id="account-type-hint">
                            Decides which side increases the account.
                        </p>
                        <p class="field-error hidden" data-error-for="type"></p>
                    </div>

                    <div>
                        <label for="account-code" class="field-label">Code</label>
                        <input id="account-code" name="code" type="text" inputmode="numeric" maxlength="4"
                               class="field-input font-mono" required autocomplete="off" placeholder="5300">
                        <p class="mt-1.5 text-xs text-muted-foreground" id="account-code-hint">
                            Four digits, inside the band for the chosen type.
                        </p>
                        <p class="field-error hidden" data-error-for="code"></p>
                    </div>
                </div>

                <div>
                    <label for="account-name" class="field-label">Name</label>
                    <input id="account-name" name="name" type="text" class="field-input" required
                           autocomplete="off" placeholder="Workshop Rent">
                    <p class="field-error hidden" data-error-for="name"></p>
                </div>

                <div>
                    <label for="account-description" class="field-label">Description</label>
                    <textarea id="account-description" name="description" rows="2" class="field-input !h-auto py-2"
                              placeholder="What belongs in this account?"></textarea>
                    <p class="field-error hidden" data-error-for="description"></p>
                </div>
            </div>

            <div class="flex justify-end gap-2 border-t border-border px-6 py-4">
                <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
                <button type="submit" class="btn btn-primary">Save account</button>
            </div>
        </form>
    </div>
</div>

@include('partials.confirm-modal')

@endsection
