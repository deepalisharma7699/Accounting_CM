@extends('layouts.app')

@section('title', 'Parties')
@section('page', 'parties')

@section('content')

<header class="mb-6 flex flex-wrap items-start justify-between gap-4">
    <div>
        <h2 class="text-2xl font-bold tracking-tight text-foreground">Parties</h2>
        <p class="mt-1.5 text-[0.9375rem] text-muted-foreground">
            Everyone the workshop trades with. One record per business, whether you sell to them, buy
            from them, or both — so their whole position sits in one place instead of two halves that
            never meet.
        </p>
    </div>

    <button type="button" id="new-party" class="btn btn-primary hidden"
            data-requires-permission="WRITE:PARTIES">
        <x-icon name="plus" :size="17" />
        New party
    </button>
</header>

<div class="surface mb-4 flex flex-wrap items-center gap-3 p-3">
    <div class="relative min-w-56 flex-1">
        <span class="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
            <x-icon name="search" :size="17" />
        </span>
        <input type="search" id="filter-search" class="field-input pl-9"
               placeholder="Search by name, phone, email or GSTIN…" aria-label="Search parties">
    </div>

    {{-- Membership, not equality: "Customers" includes the counterparty who is
         also a vendor, or the one record modelling both sides of a relationship
         would vanish from both lists. --}}
    <select id="filter-role" class="field-input w-auto min-w-40" aria-label="Filter by role">
        <option value="">Customers &amp; vendors</option>
        @foreach (\App\Enums\PartyRole::cases() as $role)
            <option value="{{ $role->value }}">{{ $role->label() }}s</option>
        @endforeach
    </select>

    <select id="filter-status" class="field-input w-auto min-w-40" aria-label="Filter by status">
        <option value="1">Active</option>
        <option value="0">Archived</option>
        <option value="">Active &amp; archived</option>
    </select>
</div>

<div class="surface overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full min-w-[860px] border-collapse">
            <thead>
                <tr class="border-b border-border bg-secondary/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th class="px-4 py-3 font-semibold">Party</th>
                    <th class="px-4 py-3 font-semibold">Role</th>
                    <th class="px-4 py-3 font-semibold">GSTIN</th>
                    <th class="px-4 py-3 text-right font-semibold">Receivable</th>
                    <th class="px-4 py-3 text-right font-semibold">Payable</th>
                    <th class="px-4 py-3 text-right font-semibold">Actions</th>
                </tr>
            </thead>
            <tbody id="parties-body"></tbody>
        </table>
    </div>

    <div class="flex flex-wrap items-center justify-between gap-3 border-t border-border px-4 py-3">
        <p id="parties-summary" class="text-[0.8125rem] text-muted-foreground"></p>

        <div class="flex gap-2">
            <button type="button" id="page-prev" class="btn btn-secondary btn-sm" disabled>Previous</button>
            <button type="button" id="page-next" class="btn btn-secondary btn-sm" disabled>Next</button>
        </div>
    </div>
</div>

{{-- Create / edit --}}
<div id="party-modal" class="modal-backdrop hidden" data-modal role="dialog" aria-modal="true"
     aria-labelledby="party-modal-title">
    <div class="modal-panel max-w-xl">
        <form id="party-form" novalidate>
            <input type="hidden" name="id">

            <div class="flex items-center justify-between border-b border-border px-6 py-4">
                <h2 id="party-modal-title" class="text-base font-bold text-foreground">New party</h2>
                <button type="button" class="btn btn-ghost btn-icon" data-modal-close aria-label="Close">
                    <x-icon name="x" :size="18" />
                </button>
            </div>

            <div class="max-h-[65vh] space-y-4 overflow-y-auto px-6 py-5">
                <p class="hidden rounded-[10px] border border-rose-200 bg-rose-50 px-3.5 py-3 text-[0.8125rem] text-rose-700"
                   data-form-banner role="alert"></p>

                <div>
                    <label for="party-name" class="field-label">Name</label>
                    <input id="party-name" name="name" type="text" class="field-input" required
                           autocomplete="off" placeholder="Bharat Winding Works">
                    <p class="mt-1.5 text-xs text-muted-foreground">
                        Names are unique, because two records with one name split a single balance in two.
                    </p>
                    <p class="field-error hidden" data-error-for="name"></p>
                </div>

                {{-- Checkboxes, not a select: the roles are genuinely
                     multi-value, and a dropdown would force the choice the
                     whole table exists to avoid. --}}
                <fieldset>
                    <legend class="field-label">Role</legend>
                    <div class="flex flex-wrap gap-4 pt-1" id="party-roles">
                        @foreach (\App\Enums\PartyRole::cases() as $role)
                            <label class="flex items-center gap-2 text-sm text-secondary-foreground">
                                <input type="checkbox" name="roles" value="{{ $role->value }}"
                                       class="size-4 rounded border-border text-primary focus:ring-ring">
                                {{ $role->label() }}
                                <span class="text-xs text-muted-foreground">({{ $role->positionLabel() }})</span>
                            </label>
                        @endforeach
                    </div>
                    <p class="mt-1.5 text-xs text-muted-foreground">
                        Tick both if you sell to them and buy from them — they will have one combined ledger.
                    </p>
                    <p class="field-error hidden" data-error-for="roles"></p>
                </fieldset>

                <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                        <label for="party-gstin" class="field-label">GSTIN</label>
                        <input id="party-gstin" name="gstin" type="text" maxlength="15"
                               class="field-input font-mono uppercase" autocomplete="off"
                               placeholder="27AAAAA0000A1Z5">
                        <p class="mt-1.5 text-xs text-muted-foreground" id="party-state-hint">
                            Optional. The first two digits set the state, which decides CGST/SGST or IGST.
                        </p>
                        <p class="field-error hidden" data-error-for="gstin"></p>
                    </div>

                    <div>
                        <label for="party-phone" class="field-label">Phone</label>
                        <input id="party-phone" name="phone" type="tel" class="field-input"
                               autocomplete="off" placeholder="98765 43210">
                        <p class="field-error hidden" data-error-for="phone"></p>
                    </div>
                </div>

                <div>
                    <label for="party-email" class="field-label">Email</label>
                    <input id="party-email" name="email" type="email" class="field-input" autocomplete="off">
                    <p class="field-error hidden" data-error-for="email"></p>
                </div>

                <div>
                    <label for="party-address" class="field-label">Address</label>
                    <textarea id="party-address" name="address" rows="2"
                              class="field-input !h-auto py-2"></textarea>
                    <p class="field-error hidden" data-error-for="address"></p>
                </div>

                <div>
                    <label for="party-notes" class="field-label">Notes</label>
                    <textarea id="party-notes" name="notes" rows="2" class="field-input !h-auto py-2"
                              placeholder="Payment terms, site contact, anything worth remembering."></textarea>
                    <p class="field-error hidden" data-error-for="notes"></p>
                </div>
            </div>

            <div class="flex justify-end gap-2 border-t border-border px-6 py-4">
                <button type="button" class="btn btn-secondary" data-modal-close>Cancel</button>
                <button type="submit" class="btn btn-primary">Save party</button>
            </div>
        </form>
    </div>
</div>

{{-- Party statement. A modal rather than a page of its own: it is read while
     deciding something about the party, and losing the list to see it is what
     makes people stop checking. --}}
<div id="party-ledger-modal" class="modal-backdrop hidden" data-modal role="dialog" aria-modal="true"
     aria-labelledby="party-ledger-title">
    <div class="modal-panel max-w-4xl">
        <div class="flex items-start justify-between gap-4 border-b border-border px-6 py-4">
            <div>
                <h2 id="party-ledger-title" class="text-base font-bold text-foreground">Statement</h2>
                <p id="party-ledger-subtitle" class="mt-0.5 text-[0.8125rem] text-muted-foreground"></p>
            </div>
            <button type="button" class="btn btn-ghost btn-icon" data-modal-close aria-label="Close">
                <x-icon name="x" :size="18" />
            </button>
        </div>

        <div id="party-ledger-position" class="border-b border-border px-6 py-4"></div>

        <div class="max-h-[50vh] overflow-y-auto">
            <table class="w-full min-w-[700px] border-collapse">
                <thead class="sticky top-0 bg-card">
                    <tr class="border-b border-border text-left text-xs uppercase tracking-wide text-muted-foreground">
                        <th class="px-6 py-3 font-semibold">Date</th>
                        <th class="px-4 py-3 font-semibold">Particulars</th>
                        <th class="px-4 py-3 text-right font-semibold">Debit</th>
                        <th class="px-4 py-3 text-right font-semibold">Credit</th>
                        <th class="px-6 py-3 text-right font-semibold">Balance</th>
                    </tr>
                </thead>
                <tbody id="party-ledger-rows"></tbody>
            </table>
        </div>

        <div class="flex flex-wrap items-center justify-between gap-3 border-t border-border px-6 py-3">
            <p id="party-ledger-summary" class="text-[0.8125rem] text-muted-foreground"></p>

            <div class="flex gap-2">
                <button type="button" id="ledger-prev" class="btn btn-secondary btn-sm" disabled>Previous</button>
                <button type="button" id="ledger-next" class="btn btn-secondary btn-sm" disabled>Next</button>
            </div>
        </div>
    </div>
</div>

@include('partials.confirm-modal')

@endsection
