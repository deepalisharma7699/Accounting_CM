<?php

namespace App\Repositories\Eloquent;

use App\Enums\PartyRole;
use App\Models\Party;
use App\Models\Transaction;
use App\Repositories\Contracts\PartyRepositoryInterface;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

class EloquentPartyRepository implements PartyRepositoryInterface
{
    /**
     * Columns a client may sort by, so nothing user-supplied reaches ORDER BY.
     *
     * @var array<int, string>
     */
    private const SORTABLE = ['name', 'created_at'];

    public function findById(int $id): ?Party
    {
        return Party::find($id);
    }

    public function nameExists(string $name, ?int $exceptId = null): bool
    {
        return Party::where('name', $name)
            ->when($exceptId !== null, fn ($query) => $query->whereKeyNot($exceptId))
            ->exists();
    }

    public function sharingGstin(string $gstin, ?int $exceptId = null): Collection
    {
        return Party::where('gstin', strtoupper($gstin))
            ->when($exceptId !== null, fn ($query) => $query->whereKeyNot($exceptId))
            ->orderBy('name')
            ->get();
    }

    public function all(bool $activeOnly = false): Collection
    {
        return Party::query()
            ->when($activeOnly, fn ($query) => $query->active())
            ->orderBy('name')
            ->get();
    }

    public function create(array $attributes): Party
    {
        return Party::create($attributes);
    }

    public function update(Party $party, array $attributes): Party
    {
        $party->fill($attributes)->save();

        return $party->refresh();
    }

    public function delete(Party $party): bool
    {
        return (bool) $party->delete();
    }

    public function transactionCount(int $partyId): int
    {
        return Transaction::where('party_id', $partyId)->count();
    }

    public function paginate(array $filters, int $perPage): LengthAwarePaginator
    {
        $sort = in_array($filters['sort'] ?? null, self::SORTABLE, true)
            ? $filters['sort']
            : 'name';

        $direction = strtolower((string) ($filters['direction'] ?? 'asc')) === 'desc' ? 'desc' : 'asc';

        return Party::query()
            ->when(
                filled($filters['search'] ?? null),
                fn ($query) => $query->where(function ($query) use ($filters) {
                    $term = '%'.$filters['search'].'%';

                    $query->where('name', 'like', $term)
                        ->orWhere('phone', 'like', $term)
                        ->orWhere('email', 'like', $term)
                        ->orWhere('gstin', 'like', $term);
                })
            )
            // Role membership, not role equality: filtering for customers must
            // still return the counterparty who is also a vendor, or the one
            // record that models both sides of a relationship would disappear
            // from both lists.
            ->when(
                filled($filters['role'] ?? null) && PartyRole::tryFrom((string) $filters['role']) !== null,
                fn ($query) => $query->withRole(PartyRole::from((string) $filters['role']))
            )
            ->when(
                ($filters['is_active'] ?? null) !== null,
                fn ($query) => $query->where('is_active', $filters['is_active'])
            )
            ->when(
                ($filters['has_gstin'] ?? null) !== null,
                fn ($query) => $filters['has_gstin']
                    ? $query->whereNotNull('gstin')
                    : $query->whereNull('gstin')
            )
            ->orderBy($sort, $direction)
            // A stable tiebreaker: names are unique per workshop, but a sort by
            // created_at is not, and without this a page boundary can repeat or
            // skip a row.
            ->orderBy('id')
            ->paginate($perPage)
            ->withQueryString();
    }
}
